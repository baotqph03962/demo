﻿
Partial Class product
    Inherits System.Web.UI.Page

End Class
